package com.example.myaiaassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val requestCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF080D1C.toInt())
        }

        val title = TextView(this).apply {
            text = "🤖 MY AI ASSISTANT"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "শুরু করতে নিচের বাটন চাপো"
            textSize = 16f
            setTextColor(0xFFB8C6E5.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 28)
        }
        val start = Button(this).apply {
            text = "🎙️ হে AI চালু করো"
            setOnClickListener { requestPermissionsAndStart() }
        }
        val stop = Button(this).apply {
            text = "বন্ধ করো"
            setOnClickListener {
                stopService(Intent(this@MainActivity, VoiceService::class.java))
                status.text = "ভয়েস সহকারী বন্ধ"
            }
        }
        val info = TextView(this).apply {
            text = "চালু হলে একটি স্থায়ী নোটিফিকেশন দেখা যাবে। পরীক্ষা করতে বলো: “হে AI ইউটিউব খোলো” অথবা “হে AI সেটিংস খোলো”।"
            textSize = 14f
            setTextColor(0xFF9EABC8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }

        root.addView(title)
        root.addView(status)
        root.addView(start)
        root.addView(stop)
        root.addView(info)
        setContentView(root)
    }

    private fun requestPermissionsAndStart() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), requestCode)
        } else startVoiceService()
    }

    private fun startVoiceService() {
        val intent = Intent(this, VoiceService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        status.text = "সহকারী চালু করার অনুরোধ পাঠানো হয়েছে"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startVoiceService()
        } else {
            status.text = "মাইক্রোফোনের অনুমতি ছাড়া ভয়েস কাজ করবে না"
        }
    }
}
