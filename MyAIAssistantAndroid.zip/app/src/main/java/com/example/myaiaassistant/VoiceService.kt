package com.example.myaiaassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.provider.Settings
import java.util.Locale

class VoiceService : Service(), RecognitionListener {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var awaitingCommand = false
    private var listening = false
    private var destroyed = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("My AI Assistant চালু")
                .setContentText("“হে AI” বলে কমান্ড দেওয়ার চেষ্টা করো")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("My AI Assistant চালু")
                .setContentText("ভয়েস সহকারী চলছে")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(openApp)
                .build()
        }

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("bn", "BD")
            }
        }

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = if (Build.VERSION.SDK_INT >= 31 &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
            recognizer?.setRecognitionListener(this)
            scheduleListening(700)
        } else {
            say("এই ফোনে স্পিচ রিকগনিশন পাওয়া যায়নি।")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Voice Assistant", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun scheduleListening(delay: Long = 500) {
        if (destroyed) return
        handler.postDelayed({ startListeningNow() }, delay)
    }

    private fun startListeningNow() {
        if (destroyed || listening) return
        val sr = recognizer ?: return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            listening = true
            sr.startListening(intent)
        } catch (_: Exception) {
            listening = false
            scheduleListening(1800)
        }
    }

    override fun onReadyForSpeech(params: android.os.Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { listening = false }

    override fun onError(error: Int) {
        listening = false
        scheduleListening(1200)
    }

    override fun onResults(results: android.os.Bundle?) {
        listening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val phrase = matches?.firstOrNull()?.lowercase(Locale.ROOT).orEmpty()
        if (phrase.isNotBlank()) handlePhrase(phrase)
        scheduleListening(if (awaitingCommand) 900 else 700)
    }

    override fun onPartialResults(partialResults: android.os.Bundle?) {}
    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

    private fun handlePhrase(phrase: String) {
        val wakeWords = listOf("হে এ আই", "হে আই", "হে এআই", "hey ai", "hey a i", "হেই আই")
        if (!awaitingCommand) {
            val wake = wakeWords.firstOrNull { phrase.contains(it) }
            if (wake != null) {
                val command = phrase.substringAfter(wake).trim()
                if (command.isNotBlank()) runCommand(command)
                else {
                    awaitingCommand = true
                    say("জি, বলুন")
                }
            }
            return
        }
        awaitingCommand = false
        runCommand(phrase)
    }

    private fun runCommand(command: String) {
        val c = command.lowercase(Locale.ROOT)
        when {
            c.contains("ইউটিউব") || c.contains("youtube") -> {
                say("ইউটিউব খুলছি")
                openUrl("https://www.youtube.com/")
            }
            c.contains("ফেসবুক") || c.contains("facebook") -> {
                say("ফেসবুক খুলছি")
                openUrl("https://www.facebook.com/")
            }
            c.contains("গুগল") || c.contains("সার্চ") -> {
                val query = command
                    .replace("গুগলে", "").replace("গুগল", "")
                    .replace("সার্চ করো", "").replace("সার্চ", "").trim()
                if (query.isBlank()) say("কী সার্চ করব বলুন")
                else {
                    say("গুগলে খুঁজছি")
                    openUrl("https://www.google.com/search?q=" + Uri.encode(query))
                }
            }
            c.contains("সেটিংস") || c.contains("settings") -> {
                say("সেটিংস খুলছি")
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) { say("সেটিংস খোলা যায়নি") }
            }
            c.contains("কল") || c.contains("ফোন করো") || c.contains("ডায়াল") -> {
                say("ফোন ডায়ালার খুলছি। কল করার আগে নম্বর যাচাই করুন")
                try {
                    startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) { say("ডায়ালার খোলা যায়নি") }
            }
            c.contains("বন্ধ") || c.contains("থামো") || c.contains("চুপ") -> {
                say("ঠিক আছে, সহকারী বন্ধ করছি")
                stopSelf()
            }
            c.contains("সময়") || c.contains("কয়টা বাজে") || c.contains("কটা বাজে") -> {
                val now = java.text.SimpleDateFormat("h:mm a", Locale("bn", "BD")).format(java.util.Date())
                say("এখন সময় $now")
            }
            else -> say("এই কমান্ডটি এখনো যোগ করা হয়নি। ইউটিউব খোলো, সেটিংস খোলো, বা গুগলে সার্চ করো বলতে পারেন।")
        }
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (_: Exception) {
            say("এই লিংক খোলা যায়নি")
        }
    }

    private fun say(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "assistant_reply")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "my_ai_voice_channel"
        private const val NOTIFICATION_ID = 42
    }
}
